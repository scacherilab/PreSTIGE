#!/usr/bin/perl -w
use List::Util qw[min max];
BEGIN {$^W=0}

use Data::Dumper;

##Create list of CTCF domains


my %ctcf_domains_starts=();
my %ctcf_domains_stops=();
my %ctcf_sites=();
my $range=$ARGV[4];

open(OUTPUT, ">tmp23XDf3.txt");
open(CTCF_SITES, "<$ARGV[0]") || die "Can't open ctcf sites file\n";


while(my $line=<CTCF_SITES>){
    
    chomp $line;
    my @liner=split(/\t|\s+/, $line);
    
    push @{$ctcf_sites{$liner[0]}}, $liner[1];
    
    
}


for $key (keys %ctcf_sites){
    
    my @sorted_chr_arr=sort{$a <=> $b} @{$ctcf_sites{$key}};
    undef $ctcf_sites{$key};
    
    push @{$ctcf_sites{$key}}, @sorted_chr_arr;
    
    
}

for $key (keys %ctcf_sites){
    
    my $index=0;
    
    while($index <scalar @{$ctcf_sites{$key}}-1){
    push @{$ctcf_domains_starts{$key}}, $ctcf_sites{$key}[$index];
    push @{$ctcf_domains_stops{$key}}, $ctcf_sites{$key}[$index+1];
    $index++;
    }
    
    
    
    
}


open(ENH, "<$ARGV[2]") || die "Can't open enhancers file\n";


my %enh=();
while(my $line=<ENH>){
    
    chomp $line;
    my @liner=split(/\t|\s+/, $line);
    
   push @{$enh{$liner[0]}}, $liner[1];
   
}


open(TSS, "<$ARGV[1]") || die "Can't open tss sites file\n";


my $max_num_enhancers=0;

while(my $line=<TSS>){
    chomp $line;
    my @liner=split(/\t|\s+/, $line);
    
   #find the region this falls under
   
  ($ins_start, $ins_stop) =findCTCFDomain($liner[0], $liner[1],$range);
   print OUTPUT "$liner[0]\t";
   

  my @enhancers_in_domain=findEnhancersInDomain($liner[0], $ins_start, $ins_stop); $max_num_enhancers=scalar @enhancers_in_domain  if scalar @enhancers_in_domain > $max_num_enhancers;
   
     print OUTPUT map { "$_ \t" } @enhancers_in_domain;
     print OUTPUT "\n";
}

close OUTPUT;

open (INPUT, "<tmp23XDf3.txt");

open(OUTPUT2, ">$ARGV[3]");
while(my $line=<INPUT>){
    chomp $line;
    my @liner=split(/\t|\s+/, $line);
     print OUTPUT2 map { "$_ \t" } @liner;
     
     if($#liner < $max_num_enhancers){
       
        for(my $i=0; $i<eval{$max_num_enhancers-$#liner};$i++){
            
            print OUTPUT2 "NA\t";
        }
     }
    
    print OUTPUT2 "\n";
    
    
}
unlink("tmp23XDf3.txt");


sub findEnhancersInDomain{
    my @enhancers_arr=();
    my $chr=$_[0];
    my $start=$_[1];
    my $stop=$_[2];
   
    
   my @cand_enh=@{$enh{$chr}};
  
   foreach(@cand_enh){
    
    if($start<=$_ and $_<=$stop){
        push @enhancers_arr, $_;
    }
    
    
   }
    
    return @enhancers_arr;
    
}
sub findCTCFDomain{
    my $tss_chr=$_[0];
    my $tss_coord=$_[1];
    my @candidate_starts=@{$ctcf_domains_starts{$tss_chr}};
    my @candidate_stops=@{$ctcf_domains_stops{$tss_chr}};
     my $range=$_[2];
    
    
    for(my $i=0; $i<=$#candidate_starts;$i++){
        my $start= $candidate_starts[$i];
        my $stop=$candidate_stops[$i];
        my $left=0;
        my $right=0;
        if($start<=$tss_coord and $tss_coord<=$stop){
            
             $left=max($tss_coord-$range, $start);
             $right=min($tss_coord+$range, $stop);
             
             return $left, $right;
            
        }
   
        
        
        
        
    }
    
    
    
}

