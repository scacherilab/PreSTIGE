#!/usr/bin/perl -w
use List::Util qw[min max];
BEGIN {$^W=0}

use Data::Dumper;


my %domains_starts=();
my %domains_stops=();
my $range=$ARGV[4];

open(OUTPUT, ">tmp23XDf3.txt");
open(DOMAINS, "<$ARGV[0]") || die "Can't open domains file\n";


while(my $line=<DOMAINS>){
    
    chomp $line;
    my @liner=split(/\t|\s+/, $line);
    
    push @{$domains_starts{$liner[0]}}, $liner[1];
    push @{$domains_stops{$liner[0]}}, $liner[2];
    
    
}


open(ENH, "<$ARGV[2]") || die "Can't open enhancers file\n";


my %enh=();
while(my $line=<ENH>){
    
    chomp $line;
    my @liner=split(/\t|\s+/, $line);
    
   push @{$enh{$liner[0]}}, $liner[1];
   
}


open(TSS, "<$ARGV[1]") || die "Can't open tss sites file\n";
open(OUTPUT2, ">$ARGV[3]");

my $max_num_enhancers=0;
while(my $line=<TSS>){
    chomp $line;
    my @liner=split(/\t|\s+/, $line);
   #find the region this falls under
  ($dom_start, $dom_stop) =findDomain($liner[0], $liner[1],$range);
   print OUTPUT "$liner[0]\t";
   

  my @enhancers_in_domain=findEnhancersInDomain($liner[0], $dom_start, $dom_stop); $max_num_enhancers=scalar @enhancers_in_domain  if scalar @enhancers_in_domain > $max_num_enhancers;
   
     print OUTPUT map { "$_ \t" } @enhancers_in_domain;
     print OUTPUT "\n";
}

close OUTPUT;

open (INPUT, "<tmp23XDf3.txt");

while(my $line=<INPUT>){
    chomp $line;
    my @liner=split(/\t|\s+/, $line);
     print OUTPUT2 map { "$_ \t" } @liner;
     
     if($#liner < $max_num_enhancers){
       
        for(my $i=0; $i<eval{$max_num_enhancers-$#liner};$i++){
            
            print OUTPUT2 "NA\t";
        }
     }
    
    print OUTPUT2 "\n";
    
    
}
unlink("tmp23XDf3.txt");


sub findEnhancersInDomain{
    my @enhancers_arr=();
    my $chr=$_[0];
    my $start=$_[1];
    my $stop=$_[2];
   
    
   my @cand_enh=@{$enh{$chr}};
  
   foreach(@cand_enh){
    
    if($start<=$_ and $_<=$stop){
        push @enhancers_arr, $_;
    }
    
    
   }
    #print OUTPUT "$chr\t$start\t$stop\t";
    return @enhancers_arr;
    
}
sub findDomain{
    my $tss_chr=$_[0];
    my $tss_coord=$_[1];
    my @candidate_starts=@{$domains_starts{$tss_chr}};
    my @candidate_stops=@{$domains_stops{$tss_chr}};
     my $range=$_[2];
    
    
    for(my $i=0; $i<=$#candidate_starts;$i++){
        my $start= $candidate_starts[$i];
        my $stop=$candidate_stops[$i];
        my $left=0;
        my $right=0;
        if($start<=$tss_coord and $tss_coord<=$stop){
            
             $left=max($tss_coord-$range, $start);
             $right=min($tss_coord+$range, $stop);
             
             return $left, $right;
            
        }
   
        
        
        
        
    }
    
    
    
}

