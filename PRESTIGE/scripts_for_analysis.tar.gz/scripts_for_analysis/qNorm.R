command_params=commandArgs()
hm_output_file=command_params[4]
output_file=command_params[5]
num_db_samples=command_params[6]


qNorm<-function(mat){

nms<-colnames(mat)

out<-matrix(nrow=nrow(mat),ncol=0)

quant <- apply(apply(mat, 2, sort), 1, mean)
for (i in 1:(ncol(mat))) {
x <- mat[, i]
x <- quant[rank(x)]
out<-cbind(out, x)}
colnames(out)<-nms
return(out)}

M_f<-read.delim(hm_output_file,header=TRUE, check.names=F)
total_cols=as.numeric(num_db_samples)+4
M_f_qnorm<-qNorm(M_f[,4:total_cols]) ###change this to 4:(num_db_samples+4)
M_f_ALL<-cbind(M_f[,1:3],M_f_qnorm)

##write table to keep file in case:
write.table(M_f_ALL,file=output_file,quote=FALSE,col.names=TRUE,row.names=FALSE,sep="\t")
q()